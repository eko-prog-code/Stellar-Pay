A lightweight Stellar wallet that allows for interaction with the TestNet and MainNet along with support for any Stellar asset.

To run, `yarn install` then `yarn start`

TODO:

- Transaction History
- Mass Import Trustlines
- Export Trustlines